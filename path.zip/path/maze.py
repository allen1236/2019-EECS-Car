import node
import math
import csv
import pandas

class Maze:
    def __init__(self, filepath):
        #read file and build graph
        # data read from csv
        self.raw_data = pandas.read_csv(filepath).values
        # graph if saved here
        self.nd_dict = dict()

        # process raw_data
        self.dead_end = []

        direction = {1:'N', 2:'S', 3:'W', 4:'E'}
        
        for dt in self.raw_data:
            nd = node.Node(dt[0])
            for i in range(1,5):
                if not math.isnan(dt[i]):
                    nd.setSuccessor( int(dt[i]), direction[i], int(dt[i+4]) )
            self.nd_dict[dt[0]] = nd
            if nd.isEnd():
                self.dead_end.append( dt[0] )
    
    def shortestPath(self, nd_from, nd_to):
        """ 
        return a path (sequence of nodes) from the current node to the nearest unexplored deadend 
        e.g.
            1 -- 2 -- 3     
                 |    |  ->  shortestPath(1,4) returns [1,2,4]
                 4 -- 5
        """
        path = dict()
        unexplored = [nd_from] 
        while nd_to not in path:
            if len(unexplored) == 0:
                return []
            unexplored_copy = list(unexplored)
            for nd in unexplored_copy:
                for neighbor in self.nd_dict[nd].getSuccessors():
                    if neighbor not in path:
                        unexplored.append(neighbor)
                        path[neighbor] = nd
                unexplored.remove(nd)
        pos = nd_to
        ans = [ nd_to ]
        while pos is not nd_from:
            ans = [ path[pos] ] + ans
            pos = path[pos]
        return ans

    def get_distances( self ):
        
        dead_end = self.dead_end
        path_len = dict()
        for i in dead_end:
            for j in dead_end:
                if i != j:
                    path_len[(int(i), int(j))] = len( self.shortestPath(i, j) )-1
        return path_len 

    def find_path( self, distances ):
        path = []
        
        
        return path

    def find_full_path( self, path ):
        full_path = []

        return full_path

    def generate_cmd( self, cmd ):
        pass
